
# CSS3 Animation 

CSS animation can animate various CSS properties like color, height, position, and so on. Pure CSS animation works perfectly without JavaScript or media (e.g. GIFs), everything can be completed with HTML and CSS only.

Recently I created a video about CSS animation and to explain the topic, I used a website as a reference. 

## 👇 Reference Website link 
https://themes.envytheme.com/stike/service/advanced-analytics/ 
- (If you are the owner of this website and if you have any issue with this tutorial please email me at "shovoalways@gmail.com" I will takedown this video. No problem)
This video is only for Education.


## 📽️ Tutorial Link
https://youtu.be/eOMpq3FNlgk


## 🥰 Follow me
- [@Github](https://github.com/shovoalways/) 
- [@Facebook](https://facebook.com/shovoalways/) 
- [@Twitter](https://twitter.com/shovoalways/) 
- [@Instagram](https://instagram.com/shovoalways/) 
